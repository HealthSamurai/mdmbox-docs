MDMbox NC Voters query-retrieval evaluation, 2026-11-05.
Four demographic fields; no entity identifiers or labels in fitting.
Unsupervised transductive fitting uses the entire unlabeled population.
5,000 validation and 5,000 test queries from disjoint entity partitions.
Each query searches all other sources in the full 5M/10M population.
This is not exhaustive all-pairs population F1 or a medical dataset.
Blocking misses count as false negatives; both query directions are separate decisions.
Automatic threshold: 0.95. Tuned threshold: maximum validation F1, then precision, then threshold.
The nonidentical subset excludes pairs with all four matching fields unchanged.
No source person records, evaluation labels or record-level scores are included.
