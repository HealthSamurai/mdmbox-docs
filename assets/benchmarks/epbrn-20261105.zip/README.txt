MDMbox synthetic patient-linkage benchmarks, 2026-11-05.
Results use entity-disjoint train/validation/test partitions; the input manifest records the exact split protocol.
automatic: default 0.95 same-person threshold.
thresholdTuned: threshold selected by validation F1; no comparison or blocking edits.
Field configurations and source attribution are listed in each results.json input manifest.
Model JSON uses the shared scoring model API format. Saved variables read original source values from Patient extensions.
No input Patients are included. Dataset source URLs and hashes are in results.json.
Zero observed false positives on a synthetic split does not guarantee perfect production precision.
